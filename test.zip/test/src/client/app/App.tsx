import React from 'react';
import AppRouter from "client/app/app-router";
import { Provider } from 'react-redux';
import store from 'client/app-redux/store';

class App extends React.Component {

  render() {
    return (
      <Provider store={store}>
        <AppRouter></AppRouter>
      </Provider>
    );
  }
}


export default App;
