export { default as Header } from "client/components/header/Header-component";
export { default as Footer } from "client/components/footer/Footer";
export { default as Logout } from "client/components/logout/logout";
export { default as MainComponent } from "client/components/mainComponent/mainComponent";


