import React, { Component } from "react";
import { connect } from "react-redux";
import "./logout.scss";

class Logout extends Component {
  render() {
    return (
      <div>
        <h2>Your session has ended</h2>
        <p>Log in to the <em>RPAM website</em> to start a new session.</p>
      </div>
    );
  }
}

export default connect()(Logout);
