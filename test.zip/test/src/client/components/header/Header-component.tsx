import React from 'react';
import './../mainComponent/mainComponent.scss';

const Header = () => (
    <div className="header">
        <div className="header-title">RPAM Header</div>
    </div>
)

export default Header;