'use strict';

const LoginController = require('../controllers/LoginController').LoginController;

class LoginRouter {

  constructor(express) {

    this.routes = express.Router();

    const loginController = new LoginController();
    const ctrl = c => loginController[c].bind(loginController)();

    // this.routes.route('/')
    //   .get(loginController.login.bind(loginController));
    
    this.routes.get('/', ctrl('login'));

    this.routes.post('/newUser', ctrl('newUser'));
  
  }

  getRoutes() {
    return this.routes;
  }

}


exports.LoginRouter = LoginRouter;
