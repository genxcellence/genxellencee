'use strict';

const http = require('http');
const logger = require('../lib/logger');
const {
  query,
  body,
  validationResult
} = require('express-validator');

// const JAVA_PORT = require('../../../client.constants').JAVA_PORT;
const JAVA_PORT = 4444;

class LoginController {


  constructor() {

  }

  login() {

    return loginValidator().concat([
      validationHandler,
      function (req, res, next) {
        http.get(`http://localhost:${JAVA_PORT}/api/getPass/?id=${req.query.id}&pass=${req.query.pass}`, (resp) => {
          let data = '';
          resp.on('data', (chunk) => {
            data += chunk;
          });

          // whole res has been received.
          resp.on('end', () => {
            console.log(JSON.parse(data));
            res.status(200).send({
              "status": 200,
              "statusText": "Success",
              "message": "Call Successful!",
              "id": JSON.parse(data).id,
              "pass": JSON.parse(data).pass
            });
          });

        }).on("error", (err) => {
          console.log("Error: " + err.message);
          res.status(400).send({
            "status": 400,
            "statusText": "Failed",
            "message": "Java server not available.",
          });
        });
      }
    ]);

  }

  newUser() {
    return newUserValidator().concat([
      validationHandler,
      function(req, res, next) {

        res.status(200).send({
          "status": 200,
          "statusText": "Passed validation",
          "sanitizedBody": req.body
        })

      }
    ])
  }

}

function loginValidator() {
  return [
    query('id').exists().isAlpha(),
    query('pass').isAlphanumeric()
  ];
}

// body for test
// {
//   "first_name": "Naruto",
//   "last_name": "Uzumaki   ",
//   "birth_date": "1996-10-10",
//   "email": "hina@hyuga.com",
//   "mobile_number": " +918989898988  "
// }
function newUserValidator() {
  return [
    body('first_name').trim().isAlpha(),
    body('last_name').trim().isAlpha(),
    // body('birth_date').exists().bail().trim().isDate({'format':'YYYY/MM/DD'}),
    body('birth_date').trim().isDate({'format':'YYYY/MM/DD'}).withMessage('Should be a valid date in format YYYY/MM/DD'),
    body('email').trim().isEmail().normalizeEmail(),
    body('mobile_number').trim().isMobilePhone("en-IN", {'strictMode': true, }).withMessage('Must be an Indian number starting with +91')
  ];
}

function validationHandler(req, res, next) {
  const validationErrors = validationResult(req);
  if (!validationErrors.isEmpty()) {
    const errMsg = errorMessage(validationErrors);
    logger.warn(errMsg);
    res.status(400).send({
      "status": 400,
      "statusText": "Failed",
      "message": errMsg,
    });
    // res.status(400).send(errMsg);
  } else {
    next();
  }
}
function errorFormatter(error) {
  if (error.nestedErrors !== undefined && error.nestedErrors !== null) {
    return `${error.nestedErrors[0].param} in ${error.nestedErrors[0].location}: ${error.nestedErrors[0].msg}`;
  }
  return `${error.param} in ${error.location}: ${error.msg}`;
}
function errorMessage(validationObj) {
  return validationObj.array().map(errorFormatter).join('\n');
}


exports.LoginController = LoginController;