exports.REACT_PORT = 2222;
exports.NODE_PORT = 3333;
exports.JAVA_PORT = 4444;